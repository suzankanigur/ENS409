function runge_kutta_4th_method_5(X, y0, y_exact, h)
    N = numel(X);
    y_estimate = zeros(size(X));
    y_estimate(1) = y0;

    for i = 2:N
        temp = X(i-1)^2 - y_estimate(i-1) - 2;
        k1 = h * temp;
        k2 = h * (X(i-1) + h/2)^2 - (y_estimate(i-1) + k1/2) - 2;
        k3 = h * (X(i-1) + h/2)^2 - (y_estimate(i-1) + k2/2) - 2;
        k4 = h * (X(i-1) + h)^2 - (y_estimate(i-1) + k3) - 2;
        y_estimate(i) = y_estimate(i-1) + (k1 + 2*k2 + 2*k3 + k4) / 6;
    end

    subplot(1,2,1)
    plot(X, y_exact, 'LineWidth', 1, 'Color', 'red')
    legend("Exact solution");
    grid on

    subplot(1,2,2)
    plot(X, y_estimate, 'LineWidth', 1, 'Color', 'green')
    legend("Runge-Kutta 4th Approx");
    grid on
end

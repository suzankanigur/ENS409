clc;
clear;

%% Parameters and functions
h_values = [0.5, 0.25, 0.1];
x_real = -2:0.01:3;
y0 = 0;

% Define the exact solution
y_exact = x_real.^2 - 2.*x_real - 8.*exp(-x_real-2);

for h = h_values
    figure;
    eulers_method_5(x_real, y0, y_exact, h);
    sgtitle(['h = ' num2str(h)]);
    runge_kutta_2nd_method_5(x_real, y0, y_exact, h);
    sgtitle(['h = ' num2str(h)]);
    runge_kutta_4th_method_5(x_real, y0, y_exact, h);
    sgtitle(['h = ' num2str(h)]);
end
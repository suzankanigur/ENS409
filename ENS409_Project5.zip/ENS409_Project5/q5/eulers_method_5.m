function eulers_method_5(X, Y, y_exact, h)
    est_func = @(x, y) (x^2 - y - 2);
    y_estimate = Y;
    for i = 2:numel(X)
        temp = est_func(X(i - 1), y_estimate(i - 1));
        y_estimate(i) = y_estimate(i - 1) + temp * h;
    end
    
    figure
    subplot(1,2,1)
    plot(X, y_exact, 'LineWidth', 1, 'color', 'red')
    legend("Exact solution");
    grid on
    subplot(1,2,2)
    plot(X, y_estimate, 'LineWidth', 1, 'color', 'green')
    legend("Euler's Method Approximation");
    grid on
end
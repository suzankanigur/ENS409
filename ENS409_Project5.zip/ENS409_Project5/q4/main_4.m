clc;
clear;

%%
h = 0.1;
x_real = 0:h:1;
y0 = 1;

syms x y(x)
eqn = diff(y) == y - exp(x);  
cond = y(0) == 1;             
sol = dsolve(eqn, cond);
y_exact = subs(sol, x, 1);

%%
estimate_euler = eulers_method_4(x_real, y0, h);
absolute_error_euler = abs(y_exact - estimate_euler);
fprintf("Approximate solution using Eulers Method is %.8f\n", estimate_euler);
fprintf("Absolute error at 1 using Eulers Method is %.8f\n", absolute_error_euler);

estimate_kutta2 = runge_kutta_2nd_method_4(x_real, y0, h);
absolute_error_kutta2 = abs(y_exact - estimate_kutta2);
fprintf("Approximate solution using Runge Kutta 2nd Method is %.8f\n", estimate_kutta2);
fprintf("Absolute error at 1 using Runge Kutta 2nd Method is %.8f\n", absolute_error_kutta2);

estimate_kutta4 = runge_kutta_4th_method_4(x_real, y0, h);
absolute_error_kutta4 = abs(y_exact - estimate_kutta4);
fprintf("Approximate solution using Runge Kutta 4th Method is %.8f\n", estimate_kutta4);
fprintf("Absolute error at 1 using Runge Kutta 4th Method is %.8f\n", absolute_error_kutta4);

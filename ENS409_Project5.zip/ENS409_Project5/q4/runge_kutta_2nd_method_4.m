function estimate = runge_kutta_2nd_method_4(X, Y, h)
    est_func = @(x, y)(y - exp(x));
    y_estimate(1) = Y;
    
    for i = 2:numel(X)
        temp = est_func(X(i-1), y_estimate(i-1));
        k1 = h * temp;
        k2 = h * est_func(X(i-1) + h/2, y_estimate(i-1) + k1/2);
        y_estimate(i) = y_estimate(i-1) + k2;
        if X(i) == Y
            estimate = y_estimate(i);
        end
    end
end

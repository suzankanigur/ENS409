function estimate = runge_kutta_4th_method_4(X, Y, h)
    est_func = @(x, y)(y - exp(x));
    y_estimate(1) = Y;
    
    for i = 2:numel(X)
        temp = est_func(X(i-1), y_estimate(i-1));
        temp2 = est_func(X(i-1) + h/2, y_estimate(i-1) + h/2 * temp);
        temp3 = est_func(X(i-1) + h/2, y_estimate(i-1) + h/2 * temp2);
        temp4 = est_func(X(i-1) + h, y_estimate(i-1) + h * temp3);
        y_estimate(i) = y_estimate(i-1) + (temp + 2*temp2 + 2*temp3 + temp4) * h/6;
        
        if X(i) == Y
            estimate = y_estimate(i);
        end
    end
end

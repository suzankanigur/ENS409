function estimate = eulers_method_4(X, Y, h)
    est_func = @(x, y)(y - exp(x));
    y_estimate = Y;
    for i = 2:numel(X)              
        temp = est_func(X(i - 1), y_estimate(i - 1));
        y_estimate(i) = y_estimate(i - 1) + temp * h;
        if X(i) == Y
            estimate = y_estimate(i);
        end
    end
end
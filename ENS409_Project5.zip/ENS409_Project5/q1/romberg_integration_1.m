% function romberg_integration_1(t, y)
%     n = length(t);
%     R = zeros(n, n);
%     R(:, 1) = y;
% 
%     % Compute the Romberg integration table
%     for j = 2:n
%         for i = j:n
%             R(i, j) = R(i, j-1) + (R(i, j-1) - R(i-1, j-1))/(4^(j-1) - 1);
%         end
%     end
% 
%     area = R(n, n);
%     fprintf('The integral by Romberg Integration is %f\n', area);
% end


function romberg_integration_1(t, y)
    n = numel(t) - 1;  % Number of intervals
    h = (t(end) - t(1)) / n;  % Step size

    % Calculate the integral using Romberg integration
    R = zeros(n+1, n+1);
    R(1, 1) = (h/2) * (y(1) + y(end));

    for i = 2:n+1
        R(i, 1) = R(i-1, 1) + h * sum(y(i-1:i));
        for j = 2:i
            R(i, j) = R(i, j-1) + (R(i, j-1) - R(i-1, j-1)) / ((4^(j-1)) - 1);
        end
        h = h / 2;
    end

    area = R(end, end);
    fprintf('The integral by Romberg Integration is %f\n', area);
end

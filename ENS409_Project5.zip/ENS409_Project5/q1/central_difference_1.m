function plott = central_difference_1(X, Y, h)
    estimate = [];
    for i=1:size(X,2)-2
        estimate(i) = (Y(i + 2) - Y(i))/(2*h); 
    end
 
    %subplot(2, 4, 7);
    plott = plot(X(2:end -1), estimate, 'LineWidth', 1, 'color', 'green');
    %title("Central Difference Estimate");
 end
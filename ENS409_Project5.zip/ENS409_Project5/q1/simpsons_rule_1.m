function simpsons_rule_1(X,Y)
    h = (X(end) - X(1))/2;
    mid = cos((X(1) + h)*5);
    area = h/3*(Y(end) + Y(1) + 4*mid);
    fprintf('The integral by Simpson''s rule is %f\n', area);
end

function  plott = backward_difference_1(X, Y, h)
    h = -h;
    estimate = [];
    for i = 1:size(X,2)-1
        estimate(i) = (Y(i) - Y(i + 1)) / h;
    end
    
    plott = plot(X(2:end) - h/2, estimate, 'LineWidth', 1, 'color', 'black');
end

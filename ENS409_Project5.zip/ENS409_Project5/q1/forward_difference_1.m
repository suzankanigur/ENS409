function plott = forward_difference_1(X, Y, h)
    estimate = [];
    for i=1:size(X,2)-1  
        estimate(i) = ((Y(i + 1) - Y(i))/h); 
    end
 
    plott = plot(X(1:end -1), estimate, 'LineWidth', 1, 'color', 'yellow');
end
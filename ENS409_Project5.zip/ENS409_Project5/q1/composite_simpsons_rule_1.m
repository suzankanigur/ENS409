function composite_simpsons_rule_1(t, y)
    n = numel(t) - 1;  % Number of intervals
    h = (t(end) - t(1)) / n;  % Step size

    odd_sum = sum(y(3:2:end-2));  % Sum of odd-indexed y-values
    even_sum = sum(y(2:2:end-1));  % Sum of even-indexed y-values
    area = h/3 * (y(1) + 4*even_sum + 2*odd_sum + y(end));

    fprintf('The integral by Composite Simpson''s rule is %f\n', area);
end

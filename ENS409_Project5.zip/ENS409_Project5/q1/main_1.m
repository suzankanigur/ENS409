clear;
clc;
 
%% QUESTION 1
t = 0:0.2:2*pi;
y = cos(5*t);
y_der = -5*sin(5*t);
h = 0.2;

%% Derivative Approximation: Difference Formulas

figure;
hold on;
plot1 = plot(t, y, 'LineWidth', 1, 'color', 'blue');
plot2 = plot(t, y_der, 'LineWidth', 1, 'color', 'red');
plot3 = forward_difference_1(t, y, h);
plot4 = backward_difference_1(t, y, h);
plot5 = central_difference_1(t, y, h);


legend([plot1, plot2, plot3, plot4, plot5], 'Original', 'Analytical', 'Forward Difference', 'Backward Difference', 'Central Difference')
hold off;


% figure 
% subplot(2, 4, 1);
% plot(t,y, 'LineWidth', 1, 'color', 'blue')
% title("Original");
% grid on
% 
% subplot(2, 4, 2);
% plot(t,y_der, 'LineWidth', 1, 'color', 'red')
% title("Analytical");
% grid on
% 
% forward_difference_1(t, y, h)
% backward_difference_1(t, y, h)
% central_difference_1(t, y, h)

%% Derivative Approximation: Richard Extrapolation

t1 = 0:0.1:2*pi;
Y1 = cos(5*t1);
t2 = 0:0.05:2*pi;
Y2 = cos(5*t2);

figure 
subplot(2, 2, 1);
plot(t,y, 'LineWidth', 1, 'color', 'blue')
legend("Original");
grid on

subplot(2, 2, 2);
plot(t,y_der, 'LineWidth', 1, 'color', 'red')
legend("Analytical");
grid on

richards_extrapolation_1(t, y, t1, Y1, t2, Y2, h);
%% Integral Approximation: 
trapezoidal_rule_1(t,y)
simpsons_rule_1(t,y);
composite_simpsons_rule_1(t,y);
romberg_integration_1(t,y);

function richards_extrapolation_1(X,Y, X1, Y1, X2, Y2, h)
    h1 = h/2;
    h2 = h1/2;
    arr = [];
    
    for i=1:30
        arr(1,i) = (Y(i + 2) - Y(i))/(2*h); 
    end
    for i=1:30
        an = X1(2*i);
        bn = X1(2*i+2);
        arr(2,i) = (Y1(2*i+2) - Y1(2*i))/(2*h1);
    end
    for i=1:30
        an = X2(4*i);
        bn = X2(4*i+2);
        arr(3,i) = (Y2(4*i+2) - Y2(4*i))/(2*h2);
    end
    N_array = [];
    for i=1:30
        N_array(1,i) = arr(2,i) + ((arr(2,i)- arr(1,i))/3);
    end
    
    for i=1:30
        N_array(2,i) = arr(3,i) + ((arr(3,i)- arr(2,i))/3);
    end
    for i=1:30
        N_array(3,i) = N_array(2,i) + ((N_array(2,i)- N_array(1,i))/15);
    end
    subplot(2,2,[3,4])
    plot(X(2:end -1), N_array(3,:), 'LineWidth', 1, 'color', 'cyan')
    legend("Richardson Extrapolation");
end

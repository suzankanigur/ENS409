function trapezoidal_rule_1(t, y)
    h = t(2) - t(1); %step size
    area = 0;
    
    for i = 2:length(t)
        area = area + (h/2) * (y(i-1) + y(i));
    end
    fprintf('The integral by Trapezoidal rule is %f\n', area);
end
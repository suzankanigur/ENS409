function trapezoidal_rule_3(t, y, q)
    h = t(2) - t(1);
    area = 0;
    
    for i = 2:length(t)
        area = area + (h/2) * (y(i-1) + y(i));
    end
    error = abs(q-area);
    fprintf('The integral by Trapezoidal rule is %f\n', area);
    fprintf('The Absolute error of Trapezoidal rule is %f\n', error);    
end
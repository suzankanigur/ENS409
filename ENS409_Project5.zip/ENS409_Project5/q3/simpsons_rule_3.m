% function simpsons_rule_3(t, y, q)
%     h = t(2) - t(1);
%     n = numel(t) - 1;
%     fa = y(1);
%     fb = y(end);
%     sum1 = 0;
%     sum2 = 0;
%     
%     % Compute the sums
%     for i = 1:n-1
%         if mod(i, 2) == 0
%             sum2 = sum2 + y(i+1);
%         else
%             sum1 = sum1 + y(i+1);
%         end
%     end
%     area = (h / 3) * (fa + 4 * sum1 + 2 * sum2 + fb);
%     error = abs(q-area);
%     fprintf('The integral by Simpson''s rule is %f\n', area);
%     fprintf('The Absolute error of Simpson''s rule is %f\n', error); 
% end


function simpsons_rule_3(t, Y, q)
    h = (t(end) - t(1))/2;
    mid = cos((t(1) + h)*5);
    area = h/3*(Y(end) + Y(1) + 4*mid);
    error = abs(q-area);
    fprintf('The integral by Simpson''s rule is %f\n', area);
    fprintf('The Absolute error of Simpson''s rule is %f\n', error); 
end

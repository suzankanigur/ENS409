clear;
clc;

%% QUESTION 3

t = 0:0.1:4;
y = exp(t)./(cos(t)+ exp(t));
func = @(t)(exp(t)./(cos(t)+ exp(t)));
q = integral(func,0,4); % instead of int, i use integral function instead. They are the same thing.

%% Calling the functions
trapezoidal_rule_3(t,y,q);
simpsons_rule_3(t,y,q);
composite_simpsons_rule_3(t,y,q);
romberg_integration_3(t,y,q);

function backward_difference_2(X, Y, h)
    derivative_estimate = 0;
    for i = 1:size(X, 2) - 1 
        if X(i) == pi
            derivative_estimate = (Y(i) - Y(i - 1)) / h;
        end
    end
    fprintf('The Backward difference derivative estimate at x=pi: %f\n', derivative_estimate);
end

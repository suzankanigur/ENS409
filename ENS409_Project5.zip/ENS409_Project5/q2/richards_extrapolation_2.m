function richards_extrapolation_2(Y, Y1, Y2, h)
    h1 = h/2;
    h2 = h1/2;
    richardson_array = [];

    for i=1:(length(Y) - 2)
        richardson_array(1,i) = (Y(i + 2) - Y(i))/(2*h); 
    end
    for i=1:(length(Y) - 2)
        richardson_array(2,i) = (Y1(i+2) - Y1(i))/(2*h1);
    end
    for i=1:(length(Y) - 2)  
        richardson_array(3,i) = (Y2(i+2) - Y2(i))/(2*h2);
    end
    N_array = [];
    for i=1:(length(Y) - 2)
        N_array(1,i) = richardson_array(2,i) + ((richardson_array(2,i)- richardson_array(1,i))/3);
    end
    
    for i=1:(length(Y) - 2)
        N_array(2,i) = richardson_array(3,i) + ((richardson_array(3,i)- richardson_array(2,i))/3);
    end
    for i=1:(length(Y) - 2)
        N_array(3,i) = N_array(2,i) + ((N_array(2,i)- N_array(1,i))/15);
    end
    fprintf('The Richard''s extrapolation derivative estimate at x=pi: %f\n', N_array(3,i));
end
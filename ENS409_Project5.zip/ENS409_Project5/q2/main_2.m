clear;
clc;
 
%% QUESTION 2

h1 = 10^(-2);
h2 = 10^(-4);
h3 = 10^(-6);
x1 = [pi-2*h1 pi-h1 pi pi+h1 pi+2*h1];
y1 = x1.*cos(x1);
x2 = [pi-2*h2 pi-h2 pi pi+h2 pi+2*h2];
y2 = x2.*cos(x2);
x3 = [pi-2*h3 pi-h3 pi pi+h3 pi+2*h3];
y3 = x3.*cos(x3);

y_der = cos(x1) - x1.*sin(x1);

%% h1
fprintf('h = 10^(-2):\n');
forward_difference_2(x1, y1, h1)
backward_difference_2(x1, y1, h1)
central_difference_2(x1, y1, h1)
richards_extrapolation_2(y1, y2, y3, h1)
fprintf('h = 10^(-4):\n');
forward_difference_2(x2, y2, h2)
backward_difference_2(x2, y2, h2)
central_difference_2(x2, y2, h2)
richards_extrapolation_2(y1, y2, y3, h2)
fprintf('h = 10^(-6):\n');
forward_difference_2(x3, y3, h3)
backward_difference_2(x3, y3, h3)
central_difference_2(x3, y3, h3)
richards_extrapolation_2(y1, y2, y3, h3)

function Lagrange_Interpolation_1(input, x1, y1)
    myfunc = @(x)3*x*exp(x)- exp(2*x);
    Lag10 = @(x)((x-x1(2))/(x1(1)-x1(2)));
    Lag11 = @(x)((x-x1(1))/(x1(2)-x1(1)));
    lagf1 = @(x)y1(1)*Lag10(x) + y1(2)*Lag11(x);
    
    Lag20 = @(x)((x - x1(2))*(x - x1(3)))/((x1(1) - x1(2))*(x1(1) - x1(3)));
    Lag21 = @(x)((x - x1(1))*(x - x1(3)))/((x1(2) - x1(1))*(x1(2) - x1(3)));
    Lag22 = @(x)((x - x1(1))*(x - x1(2)))/((x1(3) - x1(1))*(x1(3) - x1(2)));
    lagf2 = @(x)y1(1)*Lag20(x) + y1(2)*Lag21(x) + y1(3)*Lag22(x);
    
    Lag30 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4)));
    Lag31 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4)));
    Lag32 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4)));
    Lag33 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3)));
    lagf3 = @(x)y1(1)*Lag30(x) + y1(2)*Lag31(x) + y1(3)*Lag32(x) + y1(4)*Lag33(x);
    
    Lag40 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4))*(x1(1) - x1(5)));
    Lag41 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4))*(x1(2) - x1(5)));
    Lag42 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4))*(x - x1(5)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4))*(x1(3) - x1(5)));
    Lag43 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(5)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3))*(x1(4) - x1(5)));
    Lag44 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4)))/((x1(5) - x1(1))*(x1(5) - x1(2))*(x1(5) - x1(3))*(x1(5) - x1(4)));
    lagf4 = @(x)y1(1)*Lag40(x) + y1(2)*Lag41(x) + y1(3)*Lag42(x) + y1(4)*Lag43(x) + y1(5)*Lag44(x);
    
    Lag50 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4))*(x1(1) - x1(5))*(x1(1) - x1(6)));
    Lag51 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4))*(x1(2) - x1(5))*(x1(2) - x1(6)));
    Lag52 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4))*(x1(3) - x1(5))*(x1(3) - x1(6)));
    Lag53 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(5))*(x - x1(6)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3))*(x1(4) - x1(5))*(x1(4) - x1(6)));
    Lag54 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(6)))/((x1(5) - x1(1))*(x1(5) - x1(2))*(x1(5) - x1(3))*(x1(5) - x1(4))*(x1(5) - x1(6)));
    Lag55 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(6) - x1(1))*(x1(6) - x1(2))*(x1(6) - x1(3))*(x1(6) - x1(4))*(x1(6) - x1(5)));
    lagf5 = @(x)y1(1)*Lag50(x) + y1(2)*Lag51(x) + y1(3)*Lag52(x) + y1(4)*Lag53(x) + y1(5)*Lag54(x) + y1(6)*Lag55(x);
    
    out = myfunc(input);
    o1 = lagf1(input);
    o2 = lagf2(input);
    o3 = lagf3(input);
    o4 = lagf4(input);
    out2 = lagf5(input);
    aae = abs(o4 - out2);
    aae1 = abs(out-out2);
    
    fprintf('For input %.2f', input);
    fprintf('\n')
    fprintf('The real value found by given function is %.8f', out);
    fprintf('\n')
    fprintf('The Lagrange linear interpolation value is %.8f', o1);
    fprintf('\n')
    fprintf('The Lagrange quadratic interpolation value is %.8f', o2);
    fprintf('\n')
    fprintf('The Lagrange cubic interpolation value is %.8f', o3);
    fprintf('\n')
    fprintf('The Lagrange fourth degree interpolation value is %.8f', o4);
    fprintf('\n')
    fprintf('The Lagrange fifth degree interpolation value is %.8f', out2);
    fprintf('\n')
    fprintf('The absolute approximate error is %.8f', aae);
    fprintf('\n')
    fprintf('The absolute true error is %.8f', aae1);
    fprintf('\n')
end
function Newton_Interpolation_1(input, xo, givenoutputs)
    myfunc = @(x)3*x*exp(x)- exp(2*x);
    out = myfunc(input);
    degree = length(xo) -1;
    DD = zeros(length(xo),length(givenoutputs));
    DD(:,1) = givenoutputs;
    for k = 2: degree + 1
        for i = 1: degree + 2 - k 
            DD(i, k) = (DD(i+1,k-1)-DD(i, k-1))/(xo(i + k -1) - xo(i));
        end
    end
    f1 = @(x)DD(1,1) +DD(1,2)*(x- xo(1));
    f2 = @(x)DD(1,1) +DD(1,2)*(x- xo(1)) + DD(1,3)*(x- xo(1))*(x- xo(2));
    f3 = @(x)DD(1,1) +DD(1,2)*(x- xo(1)) + DD(1,3)*(x- xo(1))*(x- xo(2)) + DD(1,4)*(x- xo(1))*(x- xo(2))*(x - xo(3));
    f4 = @(x)DD(1,1) +DD(1,2)*(x- xo(1)) + DD(1,3)*(x- xo(1))*(x- xo(2)) + DD(1,4)*(x- xo(1))*(x- xo(2))*(x - xo(3)) + DD(1,5)*(x- xo(1))*(x- xo(2))*(x - xo(3))*(x-xo(4));
    interpol = @(x)DD(1,1) +DD(1,2)*(x- xo(1)) + DD(1,3)*(x- xo(1))*(x- xo(2)) + DD(1,4)*(x- xo(1))*(x- xo(2))*(x - xo(3)) + DD(1,5)*(x- xo(1))*(x- xo(2))*(x - xo(3))*(x-xo(4)) + DD(1,6)*(x- xo(1))*(x- xo(2))*(x - xo(3))*(x-xo(4))*(x-xo(5));
    o1 = f1(input);
    o2 = f2(input);
    o3 = f3(input);
    o4 = f4(input);
    out2 = interpol(input);
    aae = abs(o4 - out2);
    aae1 = abs(out-out2);
        
    fprintf('For input %.2f', input);
    fprintf('\n')
    fprintf('The real value found by given function is %.8f', out);
    fprintf('\n')
    fprintf('The linear interpolation value is %.8f', o1);
    fprintf('\n')
    fprintf('The quadratic interpolation value is %.8f', o2);
    fprintf('\n')
    fprintf('The cubic interpolation value is %.8f', o3);
    fprintf('\n')
    fprintf('The fourth degree interpolation value is %.8f', o4);
    fprintf('\n')
    fprintf('The fifth degree interpolation value is %.8f', out2);
    fprintf('\n')
    fprintf('The absolute approximate error is %.8f', aae);
    fprintf('\n')
    fprintf('The absolute true error is %.8f', aae1);
    fprintf('\n')
end
clc;
clear;
%% Newton Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
Newton_Interpolation_1(1.04, x, y);
Newton_Interpolation_1(1.08, x, y);
Newton_Interpolation_1(1.10, x, y);

%% Lagrange Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
Lagrange_Interpolation_1(1.04, x, y);
Lagrange_Interpolation_1(1.08, x, y);
Lagrange_Interpolation_1(1.10, x, y);

%% Hermite Interpolation
x = [1, 1.05, 1.07, 1.09, 1.2, 1.23];
y = [0.76579, 0.83543, 0.85893, 0.87956, 0.92924, 0.91952];
ydev = [1.5316, 1.2422, 1.1056, 0.95608, -0.13358, -0.52159];

Hermite_Interpolation_1(1.04, x, y, ydev);
Hermite_Interpolation_1(1.08, x, y, ydev);
Hermite_Interpolation_1(1.10, x, y, ydev);
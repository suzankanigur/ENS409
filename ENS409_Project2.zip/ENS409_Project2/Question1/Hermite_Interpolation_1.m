function Hermite_Interpolation_1(input, x1, y1, y2)
    firstfunc = @(x)3*x*exp(x)- exp(2*x);
    syms x
    Lag10 = @(x)((x-x1(2))/(x1(1)-x1(2)));
    Lag11 = @(x)((x-x1(1))/(x1(2)-x1(1)));
    Hcap10 = @(x)(x - x1(1))*(Lag10(x)^2);
    Hcap11 = @(x)(x - x1(2))*(Lag11(x)^2);
    Lag10d = eval(['@(x)' char(diff(Lag10(x)))]);
    Lag11d = eval(['@(x)' char(diff(Lag11(x)))]);
    H10 = @(x)(1 - 2*(x - x1(1))*Lag10d(x1(1)))*(Lag10(x)^2);
    H11 = @(x)(1 - 2*(x - x1(2))*Lag11d(x1(2)))*(Lag11(x)^2);
    HermiteFinal1 = @(x)y1(1)*H10(x) + y1(2)*H11(x) + y2(1)*Hcap10(x) + y2(2)*Hcap11(x);
    
    
    Lag20 = @(x)((x - x1(2))*(x - x1(3)))/((x1(1) - x1(2))*(x1(1) - x1(3)));
    Lag21 = @(x)((x - x1(1))*(x - x1(3)))/((x1(2) - x1(1))*(x1(2) - x1(3)));
    Lag22 = @(x)((x - x1(1))*(x - x1(2)))/((x1(3) - x1(1))*(x1(3) - x1(2)));
    Hcap20 = @(x)(x - x1(1))*(Lag20(x)^2);
    Hcap21 = @(x)(x - x1(2))*(Lag21(x)^2);
    Hcap22 = @(x)(x - x1(3))*(Lag22(x)^2);
    Lag20d = eval(['@(x)' char(diff(Lag20(x)))]);
    Lag21d = eval(['@(x)' char(diff(Lag21(x)))]);
    Lag22d = eval(['@(x)' char(diff(Lag22(x)))]);
    H20 = @(x)(1 - 2*(x - x1(1))*Lag20d(x1(1)))*(Lag20(x)^2);
    H21 = @(x)(1 - 2*(x - x1(2))*Lag21d(x1(2)))*(Lag21(x)^2);
    H22 = @(x)(1 - 2*(x - x1(3))*Lag22d(x1(3)))*(Lag22(x)^2);
    HermiteFinal2 = @(x)y1(1)*H20(x) + y1(2)*H21(x) + y1(3)*H22(x)+ y2(1)*Hcap20(x) + y2(2)*Hcap21(x) + y2(3)*Hcap22(x);
    
    
    Lag30 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4)));
    Lag31 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4)));
    Lag32 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4)));
    Lag33 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3)));
    Hcap30 = @(x)(x - x1(1))*(Lag30(x)^2);
    Hcap31 = @(x)(x - x1(2))*(Lag31(x)^2);
    Hcap32 = @(x)(x - x1(3))*(Lag32(x)^2);
    Hcap33 = @(x)(x - x1(4))*(Lag33(x)^2);
    Lag30d = eval(['@(x)' char(diff(Lag30(x)))]);
    Lag31d = eval(['@(x)' char(diff(Lag31(x)))]);
    Lag32d = eval(['@(x)' char(diff(Lag32(x)))]);
    Lag33d = eval(['@(x)' char(diff(Lag33(x)))]);
    H30 = @(x)(1 - 2*(x - x1(1))*Lag30d(x1(1)))*(Lag30(x)^2);
    H31 = @(x)(1 - 2*(x - x1(2))*Lag31d(x1(2)))*(Lag31(x)^2);
    H32 = @(x)(1 - 2*(x - x1(3))*Lag32d(x1(3)))*(Lag32(x)^2);
    H33 = @(x)(1 - 2*(x - x1(4))*Lag33d(x1(4)))*(Lag33(x)^2);
    HermiteFinal3 = @(x)y1(1)*H30(x) + y1(2)*H31(x) + y1(3)*H32(x) + y1(4)*H33(x) + y2(1)*Hcap30(x) + y2(2)*Hcap31(x) + y2(3)*Hcap32(x) + y2(4)*Hcap33(x);
    
    
    Lag40 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4))*(x1(1) - x1(5)));
    Lag41 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4))*(x1(2) - x1(5)));
    Lag42 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4))*(x - x1(5)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4))*(x1(3) - x1(5)));
    Lag43 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(5)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3))*(x1(4) - x1(5)));
    Lag44 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4)))/((x1(5) - x1(1))*(x1(5) - x1(2))*(x1(5) - x1(3))*(x1(5) - x1(4)));
    Hcap40 = @(x)(x - x1(1))*(Lag40(x)^2);
    Hcap41 = @(x)(x - x1(2))*(Lag41(x)^2);
    Hcap42 = @(x)(x - x1(3))*(Lag42(x)^2);
    Hcap43 = @(x)(x - x1(4))*(Lag43(x)^2);
    Hcap44 = @(x)(x - x1(5))*(Lag44(x)^2);
    Lag40d = eval(['@(x)' char(diff(Lag40(x)))]);
    Lag41d = eval(['@(x)' char(diff(Lag41(x)))]);
    Lag42d = eval(['@(x)' char(diff(Lag42(x)))]);
    Lag43d = eval(['@(x)' char(diff(Lag43(x)))]);
    Lag44d = eval(['@(x)' char(diff(Lag44(x)))]);
    H40 = @(x)(1 - 2*(x - x1(1))*Lag40d(x1(1)))*(Lag40(x)^2);
    H41 = @(x)(1 - 2*(x - x1(2))*Lag41d(x1(2)))*(Lag41(x)^2);
    H42 = @(x)(1 - 2*(x - x1(3))*Lag42d(x1(3)))*(Lag42(x)^2);
    H43 = @(x)(1 - 2*(x - x1(4))*Lag43d(x1(4)))*(Lag43(x)^2);
    H44 = @(x)(1 - 2*(x - x1(5))*Lag44d(x1(5)))*(Lag44(x)^2);
    HermiteFinal4 = @(x)y1(1)*H40(x) + y1(2)*H41(x) + y1(3)*H42(x) + y1(4)*H43(x) + y1(5)*H44(x) + y2(1)*Hcap40(x) + y2(2)*Hcap41(x) + y2(3)*Hcap42(x) + y2(4)*Hcap43(x) + y2(5)*Hcap44(x);
    

    Lag50 = @(x)((x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(1) - x1(2))*(x1(1) - x1(3))*(x1(1) - x1(4))*(x1(1) - x1(5))*(x1(1) - x1(6)));
    Lag51 = @(x)((x - x1(1))*(x - x1(3))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(2) - x1(1))*(x1(2) - x1(3))*(x1(2) - x1(4))*(x1(2) - x1(5))*(x1(2) - x1(6)));
    Lag52 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(4))*(x - x1(5))*(x - x1(6)))/((x1(3) - x1(1))*(x1(3) - x1(2))*(x1(3) - x1(4))*(x1(3) - x1(5))*(x1(3) - x1(6)));
    Lag53 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(5))*(x - x1(6)))/((x1(4) - x1(1))*(x1(4) - x1(2))*(x1(4) - x1(3))*(x1(4) - x1(5))*(x1(4) - x1(6)));
    Lag54 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(6)))/((x1(5) - x1(1))*(x1(5) - x1(2))*(x1(5) - x1(3))*(x1(5) - x1(4))*(x1(5) - x1(6)));
    Lag55 = @(x)((x - x1(1))*(x - x1(2))*(x - x1(3))*(x - x1(4))*(x - x1(5)))/((x1(6) - x1(1))*(x1(6) - x1(2))*(x1(6) - x1(3))*(x1(6) - x1(4))*(x1(6) - x1(5)));
    Hcap50 = @(x)(x - x1(1))*(Lag50(x)^2);
    Hcap51 = @(x)(x - x1(2))*(Lag51(x)^2);
    Hcap52 = @(x)(x - x1(3))*(Lag52(x)^2);
    Hcap53 = @(x)(x - x1(4))*(Lag53(x)^2);
    Hcap54 = @(x)(x - x1(5))*(Lag54(x)^2);
    Hcap55 = @(x)(x - x1(6))*(Lag55(x)^2); 
   
    Lag50d = eval(['@(x)' char(diff(Lag50(x)))]);
    Lag51d = eval(['@(x)' char(diff(Lag51(x)))]);
    Lag52d = eval(['@(x)' char(diff(Lag52(x)))]);
    Lag53d = eval(['@(x)' char(diff(Lag53(x)))]);
    Lag54d = eval(['@(x)' char(diff(Lag54(x)))]);
    Lag55d = eval(['@(x)' char(diff(Lag55(x)))]);
    H50 = @(x)(1 - 2*(x - x1(1))*Lag50d(x1(1)))*(Lag50(x)^2);
    H51 = @(x)(1 - 2*(x - x1(2))*Lag51d(x1(2)))*(Lag51(x)^2);
    H52 = @(x)(1 - 2*(x - x1(3))*Lag52d(x1(3)))*(Lag52(x)^2);
    H53 = @(x)(1 - 2*(x - x1(4))*Lag53d(x1(4)))*(Lag53(x)^2);
    H54 = @(x)(1 - 2*(x - x1(5))*Lag54d(x1(5)))*(Lag54(x)^2);
    H55 = @(x)(1 - 2*(x - x1(6))*Lag55d(x1(6)))*(Lag55(x)^2);
    HermiteFinal = @(x)y1(1)*H50(x) + y1(2)*H51(x) + y1(3)*H52(x) + y1(4)*H53(x) + y1(5)*H54(x) + y1(6)*H55(x) + y2(1)*Hcap50(x) + y2(2)*Hcap51(x) + y2(3)*Hcap52(x) + y2(4)*Hcap53(x) + y2(5)*Hcap54(x) + y2(6)*Hcap55(x);
    
    out = firstfunc(input);
    o1 = HermiteFinal1(input);
    o2 = HermiteFinal2(input);
    o3 = HermiteFinal3(input);
    o4 = HermiteFinal4(input);
    out2 = HermiteFinal(input);
    aae = abs(o4 - out2);
    aae1 = abs(out-out2);
    
    fprintf('For input %.2f', input);
    fprintf('\n')
    fprintf('The value is %.8f', out);
    fprintf('\n')
    fprintf('The hermite 3rd degree interpolation value is %.8f', o1);
    fprintf('\n')
    fprintf('The hermite 5h degree interpolation value is %.8f', o2);
    fprintf('\n')
    fprintf('The hermite 7th degree interpolation value is %.8f', o3);
    fprintf('\n')
    fprintf('The hermite 8th degree interpolation value is %.8f', o4);
    fprintf('\n')
    fprintf('The hermite 11th degree interpolation value is %.8f', out2);
    fprintf('\n')
    fprintf('The absolute approximate error is %.8f', aae);
    fprintf('\n')
    fprintf('The absolute true error is %.8f', aae1);
    fprintf('\n')
end
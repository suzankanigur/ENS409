function Newton_Interpolation_3(x2, y2, x3, y3, x4, y4, x2_s, y2_s, x3_s, y3_s, x4_s, y4_s)
    myfunc = @(x)sin(pi*x)/(pi*x);
    
    degree2 = length(x2) -1;
    DD2 = zeros(length(x2),length(y2));
    DD2(:,1) = y2;
    for k = 2: degree2 + 1
        for i = 1: degree2 + 2 - k 
            DD2(i, k) = (DD2(i+1,k-1)-DD2(i, k-1))/(x2(i + k -1) - x2(i));
        end
    end
    interpol2 = @(x)DD2(1,1) + DD2(1,2)*(x - x2(1)) + DD2(1,3)*(x - x2(1))*(x - x2(2)) + DD2(1,4)*(x- x2(1))*(x- x2(2))*(x - x2(3)) + DD2(1,5)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4)) + DD2(1,6)*(x- x2(1))*(x- x2(2))*(x - x2(3))*(x-x2(4))*(x-x2(5));

    
    
    degree3 = length(x3) -1;
    DD3 = zeros(length(x3),length(y3));
    DD3(:,1) = y3;
    for k = 2: degree3 + 1
        for i = 1: degree3 + 2 - k 
            DD3(i, k) = (DD3(i+1,k-1)-DD3(i, k-1))/(x3(i + k -1) - x3(i));
        end
    end
    interpol3 = @(x)DD3(1,1) + DD3(1,2)*(x - x3(1)) + DD3(1,3)*(x - x3(1))*(x - x3(2)) + DD3(1,4)*(x - x3(1))*(x- x3(2))*(x - x3(3)) + DD3(1,5)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4)) + DD3(1,6)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5)) + DD3(1,7)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6)) + DD3(1,8)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7)) + DD3(1,9)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8)) + DD3(1,10)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9)) + DD3(1,11)*(x- x3(1))*(x- x3(2))*(x - x3(3))*(x-x3(4))*(x-x3(5))*(x-x3(6))*(x-x3(7))*(x-x3(8))*(x-x3(9))*(x-x3(10));
    
    
    
    degree4 = length(x4) -1;
    DD4 = zeros(length(x4),length(y4));
    DD4(:,1) = y4;
    for k = 2: degree4 + 1
        for i = 1: degree4 + 2 - k 
           DD4(i, k) = (DD4(i+1,k-1)-DD4(i, k-1))/(x4(i + k -1) - x4(i));
        end
    end
    interpol4 = @(x)DD4(1,1) +DD4(1,2)*(x - x4(1)) + DD4(1,3)*(x - x4(1))*(x - x4(2)) + DD4(1,4)*(x - x4(1))*(x- x4(2))*(x - x4(3)) + DD4(1,5)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4)) + DD4(1,6)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5)) + DD4(1,7)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6)) + DD4(1,8)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7)) + DD4(1,9)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8)) + DD4(1,10)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9)) + DD4(1,11)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10)) + DD4(1,12)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10)*(x-x4(11)) + DD4(1,13)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10))*(x-x4(11))*(x-x4(12)) + DD4(1,14)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10))*(x-x4(11))*(x-x4(12))*(x-x4(13)) + DD4(1,15)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10))*(x-x4(11))*(x-x4(12))*(x-x4(13))*(x-x4(14)) + DD4(1,16)*(x- x4(1))*(x- x4(2))*(x - x4(3))*(x-x4(4))*(x-x4(5))*(x-x4(6))*(x-x4(7))*(x-x4(8))*(x-x4(9))*(x-x4(10))*(x-x4(11))*(x-x4(12))*(x-x4(13))*(x-x4(14))*(x-x4(15)));
        
    
    
    
    degree2_s= length(x2_s) -1;
    DD2_s = zeros(length(x2_s),length(y2_s));
    DD2_s(:,1) = y2_s;
    for k = 2: degree2_s+ 1
        for i = 1: degree2_s+ 2 - k 
            DD2_s(i, k) = (DD2_s(i+1,k-1)-DD2_s(i, k-1))/(x2_s(i + k -1) - x2_s(i));
        end
    end
    interpol2_s = @(x)DD2_s(1,1) + DD2_s(1,2)*(x - x2_s(1)) + DD2_s(1,3)*(x - x2_s(1))*(x - x2_s(2)) + DD2_s(1,4)*(x- x2_s(1))*(x- x2_s(2))*(x - x2_s(3)) + DD2_s(1,5)*(x- x2_s(1))*(x- x2_s(2))*(x - x2_s(3))*(x-x2_s(4)) + DD2_s(1,6)*(x- x2_s(1))*(x- x2_s(2))*(x - x2_s(3))*(x-x2_s(4))*(x-x2_s(5));

    
    
    degree3_s = length(x3_s) -1;
    DD3_s = zeros(length(x3_s),length(y3_s));
    DD3_s(:,1) = y3_s;
    for k = 2: degree3_s + 1
        for i = 1: degree3_s + 2 - k 
            DD3_s(i, k) = (DD3_s(i+1,k-1)-DD3_s(i, k-1))/(x3_s(i + k -1) - x3_s(i));
        end
    end
    interpol3_s = @(x)DD3_s(1,1) + DD3_s(1,2)*(x - x3_s(1)) + DD3_s(1,3)*(x - x3_s(1))*(x - x3_s(2)) + DD3_s(1,4)*(x - x3_s(1))*(x- x3_s(2))*(x - x3_s(3)) + DD3_s(1,5)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4)) + DD3_s(1,6)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5)) + DD3_s(1,7)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5))*(x-x3_s(6)) + DD3_s(1,8)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5))*(x-x3_s(6))*(x-x3_s(7)) + DD3_s(1,9)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5))*(x-x3_s(6))*(x-x3_s(7))*(x-x3_s(8)) + DD3_s(1,10)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5))*(x-x3_s(6))*(x-x3_s(7))*(x-x3_s(8))*(x-x3_s(9)) + DD3_s(1,11)*(x- x3_s(1))*(x- x3_s(2))*(x - x3_s(3))*(x-x3_s(4))*(x-x3_s(5))*(x-x3_s(6))*(x-x3_s(7))*(x-x3_s(8))*(x-x3_s(9))*(x-x3_s(10));
    
    
    
    degree4_s = length(x4_s) -1;
    DD4_s = zeros(length(x4_s),length(y4_s));
    DD4_s(:,1) = y4_s;
    for k = 2: degree4_s + 1
        for i = 1: degree4_s + 2 - k 
           DD4_s(i, k) = (DD4_s(i+1,k-1)-DD4_s(i, k-1))/(x4_s(i + k -1) - x4_s(i));
        end
    end
    interpol4_s = @(x)DD4_s(1,1) +DD4_s(1,2)*(x - x4_s(1)) + DD4_s(1,3)*(x - x4_s(1))*(x - x4_s(2)) + DD4_s(1,4)*(x - x4_s(1))*(x- x4_s(2))*(x - x4_s(3)) + DD4_s(1,5)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4)) + DD4_s(1,6)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5)) + DD4_s(1,7)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6)) + DD4_s(1,8)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7)) + DD4_s(1,9)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8)) + DD4_s(1,10)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9)) + DD4_s(1,11)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10)) + DD4_s(1,12)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10)*(x-x4_s(11)) + DD4_s(1,13)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10))*(x-x4_s(11))*(x-x4_s(12)) + DD4_s(1,14)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10))*(x-x4_s(11))*(x-x4_s(12))*(x-x4_s(13)) + DD4_s(1,15)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10))*(x-x4_s(11))*(x-x4_s(12))*(x-x4_s(13))*(x-x4_s(14)) + DD4_s(1,16)*(x- x4_s(1))*(x- x4_s(2))*(x - x4_s(3))*(x-x4_s(4))*(x-x4_s(5))*(x-x4_s(6))*(x-x4_s(7))*(x-x4_s(8))*(x-x4_s(9))*(x-x4_s(10))*(x-x4_s(11))*(x-x4_s(12))*(x-x4_s(13))*(x-x4_s(14))*(x-x4_s(15)));
        
    
    
    
    funcx = -3:0.12:3; %50 points
    funcy1 = [];
    funcy2 = [];
    funcy3 = [];
    funcy4 = [];
    for i = 1: length(funcx)
        funcy1(i) = myfunc(funcx(i));
        funcy2(i) = interpol2(funcx(i)); 
        funcy3(i) = interpol3(funcx(i)); 
        funcy4(i) = interpol4(funcx(i));     
    end
    
    
    
    funcy1_s = [];
    funcy2_s = [];
    funcy3_s = [];
    funcy4_s = [];
    for i = 1: length(funcx)
        funcy1_s(i) = myfunc(funcx(i));
        funcy2_s(i) = interpol2_s(funcx(i)); 
        funcy3_s(i) = interpol3_s(funcx(i)); 
        funcy4_s(i) = interpol4_s(funcx(i));     
    end
    
    
    plot(funcx,funcy1,'DisplayName','original function');
    hold on
    plot(funcx,funcy2,'DisplayName','5th degree newton interpolation');
    hold on
    plot(funcx,funcy3, 'DisplayName','10th degree newton interpolation')
    hold on
    plot(funcx,funcy4, 'DisplayName','15th degree newton interpolation');
    hold on
    plot(funcx,funcy2_s,'DisplayName','5th degree sinc(x) newton interpolation');
    hold on
    plot(funcx,funcy3_s, 'DisplayName','10th degree sinc(x) newton interpolation')
    hold on
    plot(funcx,funcy4_s, 'DisplayName','15th degree sinc(x) newton interpolation');
    grid on
    legend
end
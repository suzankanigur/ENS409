clc;
clear;

%%
myf = @(x)sin(pi*x)/(pi*x);

x1 = [];
y1 = [];
x2 = [];
y2 = [];
x3 = [];
y3 = [];

x1_s = [];
y1_s = [];
x2_s = [];
y2_s = [];
x3_s = [];
y3_s = [];


deriv = @(x)(pi*cos(pi*x)-sin(pi*x))/(pi*x)^2;
y1dev = [];
y2dev = [];
y3dev = [];

deriv_s = @(x)(x*cos(x) - sin(x)) / x^2;
y1_sdev = [];
y2_sdev = [];
y3_sdev = [];


%n = 5;
for i = 1:6
    x1(i) = -3 + (6*(i-1)/5);
    x1_s(i) = sinc(i);
end
for i = 1:6
    y1(i) = myf(x1(i));
    y1_s(i) = myf(x1_s(i));
    y1dev(i) = deriv(x1(i));
    y1_sdev(i) = deriv_s(x1_s(i));
end

%n = 10;
for i = 1:11
    x2(i) = -3 + (6*(i-1)/10);
    x2_s(i) = sinc(i);
end
for i = 1:11
    y2(i) = myf(x2(i));
    y2_s(i) = myf(x2_s(i));
    y2dev(i) = deriv(x2(i));
    y2_sdev(i) = deriv_s(x2_s(i));
end

%n = 15;
for i = 1:16
    x3(i) = -3 + (6*(i-1)/15);
    x3_s(i) = sinc(i);
end
for i = 1:16
    y3(i) = myf(x3(i));
    y3_s(i) = myf(x3_s(i));
    y3dev(i) = deriv(x3(i));
    y3_sdev(i) = deriv_s(x3_s(i));
end

%%
Newton_Interpolation_3(x1, y1, x2, y2, x3, y3, x1_s, y1_s, x2_s, y2_s, x3_s, y3_s);

%%
Lagrange_Interpolation_3(x1, y1, x2, y2, x3, y3);

%%
Lagrange_Interpolation_3(x1_s, y1_s, x2_s, y2_s, x3_s, y3_s);

%%
Hermite_Interpolation_3(x1, y1, y1dev, x2, y2, y2dev, x3, y3, y3dev);

%%
Hermite_Interpolation_3(x1_s, y1_s, y1_sdev, x2_s, y2_s, y2_sdev, x3_s, y3_s, y3_sdev);
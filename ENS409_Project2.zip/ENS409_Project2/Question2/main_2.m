clc;
clear;

%%
myf = @(x)1/(1+ exp(-x));
x = linspace(-5,5,20);
% Choose random x values

idx = randperm(length(x));

x1 = x(idx(1:4));
x2 = x(idx(5:10));
x3 = x(idx(11:19));

% Newton Interpolation

y1 = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
end

y2 = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
end

y3 = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
end

[newton_3, newton_5, newton_8] = Newton_Interpolation_2(x1, y1, x2, y2, x3, y3);

% Lagrange Interpolation

y1 = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
end

y2 = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
end

y3 = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
end
[lagrange_3, lagrange_5, lagrange_8] = Lagrange_Interpolation_2(x1, y1, x2, y2, x3, y3);

% Hermite Interpolation

fd = @(x)1/(1+ exp(-x))^-2;
y1 = [];
y1dev = [];
for i = 1: length(x1)
    y1(i) = myf(x1(i));
    y1dev(i) = fd(x1(i));
end

y2 = [];
y2dev = [];
for i = 1: length(x2)
    y2(i) = myf(x2(i));
    y2dev(i) = fd(x2(i));
end

y3 = [];
y3dev = [];
for i = 1: length(x3)
    y3(i) = myf(x3(i));
    y3dev(i) = fd(x3(i));
end
[hermite_3, hermite_5, hermite_8] = Hermite_Interpolation_2(x1, y1, y1dev, x2, y2,y2dev, x3, y3, y3dev);

% Ploting

%% n=3
plot(newton_3,'DisplayName','3rd degree Newton interpolation')
hold on
plot(lagrange_3,'DisplayName','3rd degree Lagrange interpolation')
hold on
plot(hermite_3,'DisplayName','3rd degree Hermite interpolation')
grid on 
legend

%% n=5
plot(newton_5,'DisplayName','5th degree Newton interpolation')
hold on
plot(lagrange_5,'DisplayName','5th degree Lagrange interpolation')
hold on
plot(hermite_5,'DisplayName','5th degree Hermite interpolation')
grid on 
legend

%% n=8
plot(newton_8,'DisplayName','8th degree Newton interpolation')
hold on
plot(lagrange_8,'DisplayName','8th degree Lagrange interpolation')
hold on
plot(hermite_8,'DisplayName','8th degree Hermite interpolation')
grid on 
legend


% Extra Plotings for each Interpolation Seperately

%% Newton

plot(newton_3,'DisplayName','3rd degree Newton interpolation')
hold on
plot(newton_5,'DisplayName','5th degree Newton interpolation')
hold on
plot(newton_8,'DisplayName','8th degree Newton interpolation')
grid on 
legend

%% Lagrange

plot(lagrange_3,'DisplayName','3rd degree Lagrange interpolation')
hold on
plot(lagrange_5,'DisplayName','5th degree Lagrange interpolation')
hold on
plot(lagrange_8,'DisplayName','8th degree Lagrange interpolation')
grid on 
legend

%% Hermite

plot(hermite_3,'DisplayName','3rd degree Hermite interpolation')
hold on
plot(hermite_5,'DisplayName','5th degree Hermite interpolation')
hold on
plot(hermite_8,'DisplayName','8th degree Hermite interpolation')
grid on 
legend
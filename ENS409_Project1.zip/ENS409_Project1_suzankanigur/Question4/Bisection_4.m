function [x, iter_count, fzero_x] = Bisection_4(lb, ub, max_iter, tol)
    func = @(x)2*x^2 - x^3 - cos(x);
    boundary = [lb ub];
    iter_count = 0; 
    p = -1;
    i = 0;
    fzero_x = fzero(func, boundary);
    error = 1000;
    value(1) = 0;
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        iter_count = iter_count + 1;
        f_lb = func(boundary(1));
        p = (boundary(1) + boundary(2)) / 2;
        f_p = func(p); 
        value(i) = p;

        if((f_lb * f_p) > 0)
            boundary(1) = p;

        elseif((f_lb * f_p) < 0)
            boundary(2) = p; 

        else
            break;
        end
        if(i > 1)
            error = abs(value(i) - value(i-1))/ abs(value(i));
        end
    end
    x = p;
end
function [x, iter_count, fzero_x] = Fixed_Point_Iteration_4(initial, max_iter, tol)
    func = @(x)2*x^2 - x^3 - cos(x);
    func_g = @(x)(-2*x^3 + 2*x^2 + x*sin(x) + cos(x)) / (-3*x^2 + 4*x + sin(x)); %derived this from the main func by x - (f(x)/f'(x))
    
    value(1) = initial; 
    iter_count = 0; 
    error = 1000;
    i = 1;
    fzero_x = fzero(func, [1 3]);
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        value(i) = func_g(value(i-1));
        iter_count = iter_count + 1;
        error = abs(value(i) - value(i-1));
        if(i > 1)
            error = abs(value(i) - value(i-1))/ abs(value(i));
        end 
    end
    
    x = value(i);
end
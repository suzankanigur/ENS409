function [x, iter_count, fzero_x] = Modified_False_Position_4(lb, ub, max_iter, tol)
    func = @(x)2*x^2 - x^3 - cos(x);
    iter_count = 0; 
    left_iter_count = 0;
    right_iter_count = 0;
    p = -1;
    f_lb = func(lb);
    f_ub = func(ub);
    boundary = [lb ub];
    fzero_x = fzero(func, boundary);
    error = 1000;
    
    while(error > tol && iter_count < max_iter)
        p = boundary(1) + ((f_lb*(boundary(1) - boundary(2)))/(f_ub - f_lb));
        f_p = func(p);
        iter_count = iter_count + 1;
        
        if(f_lb*f_p > 0)
           left_iter_count = 0; 
           right_iter_count = right_iter_count + 1;
           boundary(1) = p;
           f_lb = func(lb);
           
           if(right_iter_count >= 2)
               f_ub = f_ub/2;
           end
           
        elseif(f_lb*f_p < 0)
           right_iter_count = 0; 
           left_iter_count = left_iter_count + 1; 
           boundary(2) = p; 
           f_ub = func(ub);
           
           if(left_iter_count >= 2)
               f_lb = f_lb/2;
           end
           
        else
            break;
        end
    end
    
    x = p;
end
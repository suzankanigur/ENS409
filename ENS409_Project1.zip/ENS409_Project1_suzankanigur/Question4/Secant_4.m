function [x, iter_count, fzero_x] = Secant_4(first, second, max_iter, tol)
    func = @(x)2*x^2 - x^3 - cos(x);
    boundary = [first second];
    iter_count = 0;
    error = 1000;
    i = 2;
    fzero_x = fzero(func, [1 3]);
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        boundary(i) = boundary(i-1) + (func(boundary(i-1))*(boundary(i-2)-boundary(i-1))) / (func(boundary(i-1))- func(boundary(i-2)));
        iter_count = iter_count + 1;
        error = abs(boundary(i) - boundary(i-1));
        if(i > 2)
            error = abs(boundary(i) - boundary(i-1))/ abs(boundary(i));
        end 
    end
    x = boundary(i);
end
function [x, err, fzero_x, errors] = Bisection_2(max_iter)
    func = @(x)x^2 - x - exp(-x);
    lb = 1;
    ub = 2;
    boundary = [lb ub];
    iter_count = 0; 
    p = -1;
    fzero_x = fzero(func, boundary);
    errors = zeros(max_iter, 1); % initialize vector for errors

    while(iter_count < max_iter)
        f_lb = func(boundary(1));
        p = (boundary(1) + boundary(2)) / 2;
        f_p = func(p); 

        if((f_lb * f_p) > 0)
            boundary(1) = p;
        elseif((f_lb * f_p) < 0)
            boundary(2) = p; 
        else
            break;
        end
        iter_count = iter_count + 1;
        
        % compute and store the absolute true error in each iteration
        errors(iter_count) = abs(fzero_x - p);
    end
    
    x = p;
    err = (abs(fzero_x - x)) / (abs(fzero_x));
    
    % plot the error versus the iteration number
    plot(1:10, errors(1:10), '-o');
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('Bisection Method');
end
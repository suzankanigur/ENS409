clc;
clear;


%% Bisection Method
fprintf("Bisection Method \n");
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = Bisection_2(max_iter);
fprintf('The founded root is %.8f', x);
fprintf('\n')
fprintf('The root found by fzero function is %.6f', fzero_x);
fprintf('\n')
fprintf('The relative error is %d', err);
fprintf('\n')


%% False Position Method
fprintf("False Position Method \n");
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = False_Position_2(max_iter);
fprintf('The founded root is %.8f', x);
fprintf('\n')
fprintf('The root found by fzero function is %.6f', fzero_x);
fprintf('\n')
fprintf('The relative error is %.6f', err);
fprintf('\n')


%% Modified False Position Method
fprintf("Modified False Position Method \n");
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = Modified_False_Position_2(max_iter);
fprintf('The founded root is %.8f', x);
fprintf('\n')
fprintf('The root found by fzero function is %.6f', fzero_x);
fprintf('\n')
fprintf('The first 10 relative errors are: ');
for i=1:min(10,length(err))
    fprintf('%.6f ', err(i));
end
fprintf('\n');



%% Newton Method
fprintf("Newton Method \n");
initial = input('Enter the initial point: ');
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = Newton_2(initial, max_iter);
fprintf('The founded root is %.8f', x);
fprintf('\n')
fprintf('The root found by fzero function is %.6f', fzero_x);
fprintf('\n')
fprintf('The first 10 relative errors are: ');
fprintf('%.6f ', err);
fprintf('\n');


%% Secant Method
fprintf("Secant Method \n");
first_approx = input('Enter the first approximation: ');
second_approx = input('Enter the second approximation: ');
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = Secant_2(first_approx, second_approx, max_iter);
fprintf('The founded root is %.8f\n', x);
fprintf('The root found by fzero function is %.6f\n', fzero_x);
fprintf('The first 10 relative errors are:');
fprintf('%.6f', err(1:10));
fprintf('\n');


%% Fixed Point Iteration
fprintf("Fixed Point Iteration Method \n");
initial = input('Enter the initial value: ');
max_iter = input('Enter the maximum iteration number: ');
[x, err, fzero_x] = Fixed_Point_Iteration_2(initial, max_iter);
fprintf('The founded root is %.8f\n', x);
fprintf('The root found by fzero function is %.6f\n', fzero_x);
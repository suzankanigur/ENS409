function [x, err, fzero_x] = Secant_2(first_approx, second_approx, max_iter)
    func = @(x)x^2 - x - exp(-x);
    boundary = [first_approx second_approx];
    iter_count = 0;
    s = fzero(func, [1 2]);
    i = 3;
    errors = zeros(max_iter, 1); % initialize error vector
    
    while(iter_count < max_iter)
        boundary(i) = boundary(i-1) + (func(boundary(i-1))*(boundary(i-2)-boundary(i-1))) / (func(boundary(i-1))- func(boundary(i-2)));
        iter_count = iter_count + 1;
        i = i + 1;
        errors(iter_count) = abs(s - boundary(i-1)) / abs(s); % add error to vector
    end
    
    x = boundary(i-1);
    err = errors(1:iter_count); % extract errors up to iteration count
    fzero_x = s;
    
    % plot the error versus the iteration number
    figure;
    plot(1:max_iter, err, '-o');
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('Secant Method');
end
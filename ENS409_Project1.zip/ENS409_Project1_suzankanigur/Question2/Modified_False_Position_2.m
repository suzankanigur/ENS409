function [x, err, fzero_x] = Modified_False_Position_2(max_iter)
    func = @(x)x^2 - x - exp(-x);
    lb = 1;
    ub = 2;
    iter_count = 0; 
    left_iter_count = 0;
    right_iter_count = 0;
    p = -1;
    f_lb = func(lb);
    f_ub = func(ub);
    boundary = [lb ub];
    score = fzero(func, boundary);
    errors = zeros(max_iter, 1); % initialize error vector
    
    while(iter_count < max_iter)
        p = boundary(1) + ((f_lb*(boundary(1) - boundary(2)))/(f_ub - f_lb));
        f_p = func(p);
        
        if(f_lb*f_p > 0)
           left_iter_count = 0; 
           right_iter_count = right_iter_count + 1;
           boundary(1) = p;
           f_lb = func(lb);
           
           if(right_iter_count >= 2)
               f_ub = f_ub/2;
           end
           
        elseif(f_lb*f_p < 0)
           right_iter_count = 0; 
           left_iter_count = left_iter_count + 1; 
           boundary(2) = p; 
           f_ub = func(ub);
           
           if(left_iter_count >= 2)
               f_lb = f_lb/2;
           end
           
        else
            break;
        end
        
        iter_count = iter_count + 1;
        errors(iter_count) = abs(score - p) / abs(score); % add error to vector
    end
    
    x = p;
    err = errors(1:iter_count); % extract errors up to iteration count
    fzero_x = score;
    
    % plot the error versus the iteration number
    figure;
    plot(1:10, err(1:10), '-o');
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('Modified False Position Method');
end
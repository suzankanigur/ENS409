function [x, err, fzero_x] = Fixed_Point_Iteration_2(initial, max_iter)
    func = @(x)x^2 - x - exp(-x);
    func_g = @(x)(x^2  + (x+1)*exp(-x)) / (exp(-x) + 2*x - 1); %derived this from the main func by x - (f(x)/f'(x))
        
    value(1) = initial; 
    iter_count = 0; 
    score = fzero(func, [1 2]);
    i = 2;
    
    while(iter_count < max_iter)
        value(i) = func_g(value(i-1));
        iter_count = iter_count + 1;
        i = i + 1;
    end
    
    x = value(i-1);
    err = abs(score - value) / abs(score);
    fzero_x = score;
    
    % plot the error versus the iteration number
    figure;
    if numel(err) >= 10
        plot(1:10, abs(err(1:10)), '-o');
    else
        plot(1:numel(err), abs(err), '-o');
    end
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('Fixed-Point Iteration Method');
end

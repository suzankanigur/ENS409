function [x, err, fzero_x] = Newton_2(initial, max_iter)
    func =  @(x)x^2 - x - exp(-x); 
    derivative = @(x)2*x + exp(-x) -1;
    boundary(1) = initial; 
    count = 0; 
    score = fzero(func, [1 2]);
    errors = zeros(max_iter, 1); % initialize error vector
    i = 2;
    
    while(count < max_iter)
        boundary(i) = boundary(i-1) - (func(boundary(i-1))/derivative(boundary(i-1)));
        count = count + 1;
        i = i + 1;
        errors(count) = abs(score - boundary(i-1)) / abs(score); % add error to vector
    end
    
    x = boundary(i-1);
    err = errors(1:10); % extract first 10 errors
    fzero_x = score;
    
    % plot the error versus the iteration number
    figure;
    plot(1:10, err, '-o');
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('Newton Method');
end
function [x, err, fzero_x] = False_Position_2(max_iter)
    func = @(x)x^2 - x - exp(-x); 
    lb = 1;
    ub = 2;
    iter_count = 0;
    boundary = [lb ub];
    score = fzero(func, boundary);
    p = -1;
    errors = zeros(max_iter, 1);
    
    while(iter_count < max_iter)
        p = lb + (((func(lb))*(lb - ub)) / ((func(ub)) - (func(lb))));

        if((func(lb))*(func(p)) > 0)
            boundary(1) = p;
            
        elseif ((func(lb))*(func(p)) < 0)
            boundary(2) = p; 
            
        else 
           break;
        end
        
        iter_count = iter_count + 1;
        errors(iter_count) = (abs(score - p)) / abs(score);
        
        if iter_count == 10
            break
        end
    end
    
    x = p;
    err = (abs(score - x)) / (abs(score));
    fzero_x = score;
    
    % plot the absolute true error in the first ten iterations
    figure;
    plot(1:10, errors(1:10), '-o');
    xlabel('Iteration Number');
    ylabel('Absolute True Error');
    title('False Position Method');
end

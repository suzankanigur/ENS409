function [x, iter_count, fzero_x] = False_Position_3(max_iter)
    func = @(x)log(x^2) + x^3;
    lb = 0.1;
    ub = 1;
    tol = 1e-4;
    iter_count = 0;
    error = 1000;
    i = 0;
    value(1) = 0;
    p = -1;
    boundary = [lb ub];
    fzero_x = fzero(func, boundary);
    
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        iter_count = iter_count + 1;
        p = lb + (((func(lb))*(lb - ub)) / ((func(ub)) - (func(lb))));
        value(i) = p;
        
        if((func(lb))*(func(p)) > 0)
            lb = p;
            
        elseif ((func(lb))*(func(p)) < 0)
            ub = p; 
            
        else 
           break;
        end
        
        if(i >1)
           error = abs(value(i) - value(i-1)); 
        end
    end
    x = p;
end
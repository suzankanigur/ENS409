clc;
clear;


%% Bisection Method
fprintf("Bisection Method \n");
maxiter = input('Enter the maximum iteration number: ');
[x, iter_count, fzero_x] = Bisection_3(maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')



%% False Position Method
fprintf("False Position Method \n");
maxiter = input('Enter the maximum iteration number:');
[x, iter_count, fzero_x] = False_Position_3(maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')



%% Modified False Position Method
fprintf("Modified False Position Method \n");
maxiter = input('Enter the maximum iteration number: ');
[x, iter_count, fzero_x] = Modified_False_Position_3(maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')



%% Newton Method
fprintf("Newton Method \n");
initial = input('Enter the initial value: ');
maxiter = input('Enter the maximum iteration number: ');
[x, iter_count, fzero_x] = Newton_3(initial, maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')



%% Secant Method
fprintf("Secant Method \n");
first_approx = input('Enter the first approximation value: ');
second_approx = input('Enter the second approximation value: ');
maxiter = input('Enter the maximum iteration number: ');
[x, iter_count, fzero_x] = Secant_3(first_approx, second_approx, maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')



%% Fixed Point Iteration
fprintf("Fixed Point Iteration Method \n");
initial = input('Enter the initial value: ');
maxiter = input('Enter the maximum iteration number: ');
[x, iter_count, fzero_x] = Fixed_Point_Iteration_3(initial, maxiter);
fprintf('The root is %.10f', x);
fprintf('\n')
fprintf('The root given by fzero function is %.10f', fzero_x);
fprintf('\n')
fprintf('The iteration number is %d', iter_count);
fprintf('\n')
function [x, iter_count, fzero_x] = Newton_3(initial, max_iter)
    func =  @(x)log(x^2) + x^3;
    derivative = @(x)2*x*log(x^2) + 3*x^2;
    boundary(1) = initial;
    fzero_x = fzero(func, [0.1 1]);
    i = 1;
    tol = 1e-4;
    iter_count = 0;
    error = 1000;
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        boundary(i) = boundary(i-1) - (func(boundary(i-1))/derivative(boundary(i-1)));
        iter_count = iter_count + 1; 
        if(i > 1)
            error = abs(boundary(i) - boundary(i-1))/ abs(boundary(i));
        end 
    end
    
    x = boundary(i);
end

function [x, iter_count, fzero_x] = Fixed_Point_Iteration_3(initial, max_iter)
    func = @(x)log(x^2) + x^3;
    func_g = @(x)((2*x^2-1)*log(x^2) + 2*x^3) / (2*x*log(x^2) + 3*x^2); %derived this from the main func by x - (f(x)/f'(x))
    
    tol = 1e-4;
    value(1) = initial; 
    iter_count = 0; 
    error = 1000;
    i = 1;
    fzero_x = fzero(func, [0.1 1]);
    
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        value(i) = func_g(value(i-1));
        iter_count = iter_count + 1;
        error = abs(value(i) - value(i-1));
        if(i > 1)
            error = abs(value(i) - value(i-1))/ abs(value(i));
        end 
    end
    
    x = value(i);
end
function [x, err, iter_count] = Bisection_1(max_iter, tol)
    func = @(x)2*x^5 + 3*x^2 - 5*x + 7;
    lb = -3;
    ub = 0;
    iter_count = 0; 
    i = 0;
    value(1) = 0;
    p = -1;
    error = 1000;
    while(error > tol && iter_count < max_iter)
        i = i + 1;
        p = (lb + ub) /2; 
        value(i) = p;

        if((func(lb))*(func(p)) > 0)
            lb = p;
        elseif ((func(lb))*(func(p)) < 0)
            ub = p; 
        else
            break;
        end

        if(i >1)
            error = abs(value(i) - value(i-1)); 
        end
        iter_count = iter_count + 1;
    end 
    x = p;
    err = error;
end
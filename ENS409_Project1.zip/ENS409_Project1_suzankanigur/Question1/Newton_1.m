function [x, err, iter] = Newton_1(initial, max_iter, tol)
    func = @(x)2*x^5 + 3*x^2 - 5*x + 7;
    derivative = @(x)10*x^4 + 6*x - 5; 
    boundary(1) = initial; 
    count = 0; 
    error = 1000;
    i = 2;
    while(error > tol && count < max_iter)
        boundary(i) = boundary(i-1) - (func(boundary(i-1))/derivative(boundary(i-1)));
        count = count + 1;
        error = abs(boundary(i)- boundary(i-1));
        i = i + 1;
    end
    x = boundary(i-1);
    err = error;
    iter = count;
end
function [x, err, iter] = Secant_1(first, second, max_iter, tol)
    func = @(x)2*x^5 + 3*x^2 - 5*x + 7;
    boundary = [first second];
    iter_count = 0;
    error = 1000;
    i = 3;
    while(error > tol && iter_count < max_iter)
        boundary(i) = boundary(i-1) + (func(boundary(i-1))*(boundary(i-2)-boundary(i-1))) / (func(boundary(i-1))- func(boundary(i-2)));
        iter_count = iter_count + 1;
        error = abs(boundary(i) - boundary(i-1));
        i = i + 1;
    end
    x = error;
    err = boundary(i-1);
    iter = iter_count;
end
function [x, err, iter] = Modified_False_Position_1(max_iter, tol)
    func = @(x)2*x^5 + 3*x^2 - 5*x + 7;
    lb = -3;
    ub = 0;
    iter_count = 0; 
    left_iter_count = 0;
    right_iter_count = 0;
    error = 1000;
    i = 0;
    value(1) = 0;
    p = -1;
    f_lb = func(lb);
    f_ub = func(ub);
    
    while(error > tol && iter_count < max_iter)
        i = i +1;
        p = lb + ((f_lb*(lb - ub))/(f_ub - f_lb));
        f_p = func(p);
        value(i) = p;
        
        if(f_lb*f_p > 0)
           left_iter_count = 0; 
           right_iter_count = right_iter_count + 1;
           lb = p;
           f_lb = func(lb);
           
           if(right_iter_count >= 2)
               f_ub = f_ub/2;
           end
           
        elseif(f_lb*f_p < 0)
           right_iter_count = 0; 
           left_iter_count = left_iter_count + 1; 
           ub = p; 
           f_ub = func(ub);
           
           if(left_iter_count >= 2)
               f_lb = f_lb/2;
           end
        else
            break;
        end
        
        if(i >1)
           error = abs(value(i) - value(i-1)); 
        end
        
        iter_count = iter_count + 1;
    end
    
    x = p;
    err = error;
    iter = iter_count;
end
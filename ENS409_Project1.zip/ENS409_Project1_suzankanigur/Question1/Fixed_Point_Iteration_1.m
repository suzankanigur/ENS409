function [x, err, iter] = Fixed_Point_Iteration_1(initial, max_iter, tol)
    func = @(x)2*x^5 + 3*x^2 - 5*x + 7;
    func_g = @(x)(8*x^5 + 3*x^2 -7)/(10*x^4 + 6*x - 5); %derived this from the main func by x - (f(x)/f'(x))
    
    value(1) = initial; 
    iter_count = 0; 
    error = 1000;
    i = 2;
    
    while(error > tol && iter_count < max_iter)
        value(i) = func_g(value(i-1));
        iter_count = iter_count + 1;
        error = abs(value(i) - value(i-1));
        i = i + 1;
    end
    
    x = value(i-1);
    err = error;
    iter = iter_count;
end
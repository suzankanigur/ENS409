clc;
clear;


%% Bisection Method
fprintf("Bisection Method \n");
maxiter = input('Enter the maximum iter number: ');
tol = input('Enter the tolerance: ');
[x, err, iter] = Bisection_1(maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate err is %.6f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')


%% False Position Method
fprintf("False Position Method \n");
maxiter = input('Enter the maximum iter number:');
tol = input('Enter the tolerance: ');
[x, err, iter] = False_Position_1(maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate err is %.8f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')


%% Modified False Position Method
fprintf("Modified False Position Method \n");
maxiter = input('Enter the maximum iter number: ');
tol = input('Enter the tolerance: ');
[x, err, iter] = Modified_False_Position_1(maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate err is %.12f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')


%% Newton Method
fprintf("Newton Method \n");
initial = input('Enter the initial value: ');

maxiter = input('Enter the maximum iteration number: ');
tol = input('Enter the tolerance: ');

[x, err, iter] = Newton_1(initial, maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate err is %.8f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')


%% Secant Method
fprintf("Secant Method \n");
first_approx = input('Enter the first approximation value: ');
second_approx = input('Enter the second approximation value: ');
maxiter = input('Enter the maximum iteration number: ');
tol = input('Enter the tolerance: ');
[x, err, iter] = Secant_1(first_approx, second_approx, maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate error is %.8f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')


%% Fixed Point Iteration
fprintf("Fixed Point Iteration Method \n");
initial = input('Enter the initial value: ');
maxiter = input('Enter the maximum iteration number: ');
tol = input('Enter the tolerance: ');
[x, err, iter] = Fixed_Point_Iteration_1(initial, maxiter, tol);
fprintf('The root is %.8f', x);
fprintf('\n')
fprintf('The absolute approximate err is %.8f', err);
fprintf('\n')
fprintf('The iteration number is %d', iter);
fprintf('\n')
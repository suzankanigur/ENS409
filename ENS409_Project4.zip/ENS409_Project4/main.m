clc;
clear;

%% QUESTION1

A1 = [1.78 0.12 -0.18 -0.66 ; 0.12 3.63 -0.97 0.25 ; -0.18 -0.97 1.32 0.23 ; -0.66 0.25 0.23 0.98];
b1 = [-5.92 ; 1.09 ; -1.99 ; -0.83];

x_gaussian = Gaussian_elimination(A1, b1);
disp("Solution using Gaussian elimination: ");
disp(x_gaussian);

[x_LU, L, U] = LU_decomposition(A1, b1);
disp("Solution using LU Decomposition: ");
disp(x_LU);

[x_jacobi, iter_jacobi] = Jacobi(A1, b1);
disp("Solution using Jacobi Method: ");
disp(x_jacobi);

[x_gauss_seidel, iter_gauss_seidel] = Gauss_Seidel(A1, b1);
disp("Solution using Gauss-Seidel Method: ");
disp(x_gauss_seidel);

% Using the backslash operator
x_backslash = A1 \ b1;
disp("Solution using the backslash operator:");
disp(x_backslash);



%% QUESTION2

A2 = [-16 -1 3 5 5 ; -5 32 5 3 6 ; -1 3 -21 -4 -2 ; -2 3 -6 22 -5 ; 1 4 1 -2 28];

x_gaussian_inv = Gaussian_elimination_inv(A2);
disp("Inverse of the matrix using Gaussian elimination: ");
disp(x_gaussian_inv);

x_LU_inv = LU_decomposition_inv(A2);
disp("Inverse of the matrix using LU Decomposition: ");
disp(x_LU_inv);

x_jacobi_inv = Jacobi_inv(A2);
disp("Inverse of the matrix using Jacobi Method: ");
disp(x_jacobi_inv);

x_gauss_seidel_inv = Gauss_Seidel_inv(A2);
disp("Inverse of the matrix using Gauss-Seidel Method: ");
disp(x_gauss_seidel_inv);

%% QUESTION3

m_values = [5, 15, 25, 35, 45, 55, 65, 75];
num_iterations_jacobi = zeros(size(m_values)); % initialize array to store results for Jacobi
num_iterations_gauss_seidel = zeros(size(m_values)); % initialize array to store results for Gauss-Seidel

for i = 1:length(m_values)
    m = m_values(i);
    A = 2*eye(m) - diag(ones(m-1,1),1) - diag(ones(m-1,1),-1);
    b = [1; zeros(m-2,1); 1];

    % Call Jacobi function and record number of iterations
    [x_jacobi, iter_jacobi] = Jacobi(A, b);
    num_iterations_jacobi(i) = iter_jacobi;
    disp(['m = ', num2str(m), ', Jacobi:']);
    disp(x_jacobi);

    % Call Gauss-Seidel function and record number of iterations
    [x_gauss_seidel, iter_gauss_seidel] = Gauss_Seidel(A, b);
    num_iterations_gauss_seidel(i) = iter_gauss_seidel;
    disp(['m = ', num2str(m), ', Gauss-Seidel:']);
    disp(x_gauss_seidel);
end

% Plot results
plot(m_values, num_iterations_jacobi, '-o');
hold on;
plot(m_values, num_iterations_gauss_seidel, '-o');
hold off;
legend('Jacobi', 'Gauss-Seidel');
xlabel('m');
ylabel('Number of iterations');
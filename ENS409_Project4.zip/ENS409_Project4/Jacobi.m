function [x, iter] = Jacobi(A, b)
    n = length(b);
    x = zeros(n,1);
    x_new = zeros(n,1);
    tol = 1e-6;
    max_iter = 1000000000;
    iter = 0;
    while iter < max_iter
        for i = 1:n
            x_new(i) = (b(i) - A(i,:)*x + A(i,i)*x(i))/A(i,i);
        end
        if norm(x_new - x) < tol
            break;
        end
        x = x_new;
        iter = iter + 1;
    end
end
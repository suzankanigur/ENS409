function [A_inv] = LU_decomposition_inv(A)
    n = size(A,1);
    I = eye(n);
    P = eye(n);
    for k = 1:n-1
        [~, p] = max(abs(A(k:n,k)));
        p = p + k - 1;
        if A(p,k) == 0
            error('Matrix is singular');
        end
        A([k,p],k:n) = A([p,k],k:n);
        I([k,p],:) = I([p,k],:);
        P([k,p],:) = P([p,k],:);
        for i = k+1:n
            factor = A(i,k)/A(k,k);
            A(i,k+1:n) = A(i,k+1:n) - factor*A(k,k+1:n);
            A(i,k) = factor;
        end
    end
    L = tril(A,-1) + eye(n);
    U = triu(A);
    A_inv = zeros(n);
    for i = 1:n
        y = forward_substitution(L, P*I(:,i));
        A_inv(:,i) = backward_substitution(U, y);
    end
end

function [y] = forward_substitution(L, b)
    n = size(L,1);
    y = zeros(n,1);
    y(1) = b(1)/L(1,1);
    for i = 2:n
        y(i) = (b(i) - L(i,1:i-1)*y(1:i-1))/L(i,i);
    end
end

function [x] = backward_substitution(U, y)
    n = size(U,1);
    x = zeros(n,1);
    x(n) = y(n)/U(n,n);
    for i = n-1:-1:1
        x(i) = (y(i) - U(i,i+1:n)*x(i+1:n))/U(i,i);
    end
end
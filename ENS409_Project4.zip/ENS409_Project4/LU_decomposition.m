function [x, L, U] = LU_decomposition(A, b)
    n = length(b);
    L = eye(n);
    for k = 1:n-1
        for i = k+1:n
            factor = A(i,k)/A(k,k);
            A(i,k+1:n) = A(i,k+1:n) - factor*A(k,k+1:n);
            L(i,k) = factor;
        end
    end
    U = A;
    y = zeros(n,1);
    y(1) = b(1);
    for k = 2:n
        y(k) = b(k) - L(k,1:k-1)*y(1:k-1);
    end
    x = zeros(n,1);
    x(n) = y(n)/U(n,n);
    for k = n-1:-1:1
        x(k) = (y(k) - U(k,k+1:n)*x(k+1:n))/U(k,k);
    end
end
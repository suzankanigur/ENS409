function x = Gaussian_elimination(A, b)
    n = length(b);
    for k = 1:n-1
        for i = k+1:n
            factor = A(i,k)/A(k,k);
            A(i,k+1:n) = A(i,k+1:n) - factor*A(k,k+1:n);
            b(i) = b(i) - factor*b(k);
        end
    end
    x = zeros(n,1);
    x(n) = b(n)/A(n,n);
    for k = n-1:-1:1
        x(k) = (b(k) - A(k,k+1:n)*x(k+1:n))/A(k,k);
    end
end
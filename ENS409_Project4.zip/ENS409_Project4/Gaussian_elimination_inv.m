function A_inv = Gaussian_elimination_inv(A)
    n = size(A, 1);
    I = eye(n);
    A_aug = [A, I];
    
    for k = 1:n-1
        for i = k+1:n
            factor = A_aug(i,k)/A_aug(k,k);
            A_aug(i,k+1:2*n) = A_aug(i,k+1:2*n) - factor*A_aug(k,k+1:2*n);
        end
    end
    
    for k = n:-1:2
        for i = k-1:-1:1
            factor = A_aug(i,k)/A_aug(k,k);
            A_aug(i,k+1:2*n) = A_aug(i,k+1:2*n) - factor*A_aug(k,k+1:2*n);
        end
    end
    
    for i = 1:n
        A_inv(i,:) = A_aug(i,n+1:2*n)/A_aug(i,i);
    end
end

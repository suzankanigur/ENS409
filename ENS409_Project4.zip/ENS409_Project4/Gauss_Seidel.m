function [x, iter] = Gauss_Seidel(A, b)
    n = length(b);
    x = zeros(n,1);
    tol = 1e-6;
    max_iter = 100000000;
    iter = 0;
    while iter < max_iter
        for i = 1:n
            x(i) = (b(i) - A(i,1:i-1)*x(1:i-1) - A(i,i+1:n)*x(i+1:n))/A(i,i);
        end
        if norm(A*x - b) < tol
            break;
        end
        iter = iter + 1;
    end
end
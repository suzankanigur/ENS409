function A_inv = Gauss_Seidel_inv(A)
    n = size(A, 1);
    A_inv = zeros(n);
    for j = 1:n
        e_j = zeros(n, 1);
        e_j(j) = 1;
        A_inv(:, j) = Gauss_Seidel(A, e_j);
    end
end

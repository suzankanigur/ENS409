%%
clc;
clear; 

%% Loading data & Spliting data

data = load('proj3data.mat');
y = data.y;
x = data.x;

%training and test sets
n = length(x);
trainSize = round(0.8*n);
trainIdx = randperm(n,trainSize);
testIdx = setdiff(1:n,trainIdx);
xTrain = x(trainIdx);
yTrain = y(trainIdx);
xTest = x(testIdx);
yTest = y(testIdx);

%% QUESTION 1

% finding the coefficients of the least squares line approx

% Calculate the slope and y-intercept of the line of best fit using the
% normal equation
X = [ones(length(xTrain),1), xTrain];
theta = pinv(X'*X)*X'*yTrain;
slope = theta(2);
y_intercept = theta(1);

% plot data and approximation
figure;
plot(x,y,'.',xTrain,slope*xTrain + y_intercept,'-');
xlabel('x');
ylabel('y');
legend('Data','Approximation');
title('Linear Fitting on Training Data');

% compute correlation coefficient
r = corrcoef(xTest,yTest);
r = r(1,2);

% compute the coefficient of determination (R-squared) to measure how much of the 
% original uncertainty is explained by the resulting model
yMean = mean(yTest);
SSres = sum((yTest - (slope*xTest + y_intercept)).^2);
SStot = sum((yTest - yMean).^2);
R2 = 1 - SSres/SStot;

fprintf('The correlation coefficient r is %.6f', r);
fprintf('\n')
fprintf('The original uncertainty explained by the linear model is %.6f', R2);


%% QUESTION2

% Compute polynomial coefficients for degrees 3, 5, and 8 using Vandermonde matrix
V3 = [xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];
V5 = [xTrain.^5 xTrain.^4 xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];
V8 = [xTrain.^8 xTrain.^7 xTrain.^6 xTrain.^5 xTrain.^4 xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];

coeffs3 = (V3.' * V3) \ (V3.' * yTrain);
coeffs5 = (V5.' * V5) \ (V5.' * yTrain);
coeffs8 = (V8.' * V8) \ (V8.' * yTrain);

% Evaluate polynomials on a grid of x values
xGrid = linspace(min(x), max(x), 100).';
VGrid3 = [xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];
VGrid5 = [xGrid.^5 xGrid.^4 xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];
VGrid8 = [xGrid.^8 xGrid.^7 xGrid.^6 xGrid.^5 xGrid.^4 xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];

yHat3 = VGrid3 * coeffs3;
yHat5 = VGrid5 * coeffs5;
yHat8 = VGrid8 * coeffs8;

% Plot data and polynomial approximations
figure;
plot(xTrain, yTrain, '.', xGrid, yHat3, xGrid, yHat5, xGrid, yHat8);
legend('Training data', 'Degree 3', 'Degree 5', 'Degree 8');
xlabel('x');
ylabel('y');

% Compute errors for each degree
trainErr3 = yTrain - V3 * coeffs3;
trainErr5 = yTrain - V5 * coeffs5;
trainErr8 = yTrain - V8 * coeffs8;

% Plot errors
figure;
hold on;
plot(xTrain, trainErr3, '.', 'DisplayName', 'Degree 3');
plot(xTrain, trainErr5, '.', 'DisplayName', 'Degree 5');
plot(xTrain, trainErr8, '.', 'DisplayName', 'Degree 8');
xlabel('x');
ylabel('Error');
legend('show');


%% QUESTION3

z0 = ones(size(xTrain));
z1 = cos(xTrain);
z2 = sin(xTrain);
Z = [z0, z1, z2]; % use comma to concatenate z0, z1, z2 horizontally
a = (Z'*Z)\Z'*yTrain; % use backslash operator to solve (Z'*Z)a = Z'y for the vector of coeffs a.

a0 = a(1);
a1 = a(2);
a2 = a(3);

% Construct the approximation
yhat = a0*z0 + a1*z1 + a2*z2;

% Plot the data and the approximation
figure;
plot(xTrain, yTrain, '.', 'DisplayName', 'Training Data');
hold on;
plot(xTrain, yhat, '.', 'DisplayName', 'Approximation');
grid on;
legend;
xlabel('x');
ylabel('y');
title('Data and Approximation');

% Plot the relative error
figure;
abserror = abs(yTrain - yhat);
relative = abserror./abs(yTrain);
plot(xTrain, relative, '.', 'DisplayName', 'Relative Error');
grid on;
xlabel('x');
ylabel('Relative Error');
title('Relative Error');
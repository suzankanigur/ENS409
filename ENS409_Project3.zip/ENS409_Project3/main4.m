%%
clc;
clear; 

%% Loading data & Spliting data

data = load('proj3data.mat');
y = data.y;
x = data.x;

%training and test sets
n = length(x);
trainSize = round(0.8*n);
trainIdx = randperm(n,trainSize);
testIdx = setdiff(1:n,trainIdx);
xTrain = x(trainIdx);
yTrain = y(trainIdx);
xTest = x(testIdx);
yTest = y(testIdx);

%% QUESTION 1

X = [ones(length(xTrain),1), xTrain];
theta = pinv(X'*X)*X'*yTrain;
slope = theta(2);
y_intercept = theta(1);

% plot data and approximation
figure;
plot(xTest,yTest,'o',xTest,slope*xTest + y_intercept,'-');
xlabel('x');
ylabel('y');
legend('Test Data','Approximation');
title('Linear Fitting on Test Data');

% compute correlation coefficient
r = corrcoef(xTest,yTest);
r = r(1,2);

% compute the coefficient of determination (R-squared) to measure how much of the
% original uncertainty is explained by the resulting model
yMean = mean(yTest);
SSres = sum((yTest - (slope*xTest + y_intercept)).^2);
SStot = sum((yTest - yMean).^2);
R2 = 1 - SSres/SStot;

fprintf('The correlation coefficient r is %.6f', r);
fprintf('\n')
fprintf('The original uncertainty explained by the linear model is %.6f', R2);
fprintf('\n')

%% QUESTION2

% Compute polynomial coefficients for degrees 3, 5, and 8 using Vandermonde matrix
V3 = [xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];
V5 = [xTrain.^5 xTrain.^4 xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];
V8 = [xTrain.^8 xTrain.^7 xTrain.^6 xTrain.^5 xTrain.^4 xTrain.^3 xTrain.^2 xTrain ones(size(xTrain))];

coeffs3 = (V3.' * V3) \ (V3.' * yTrain);
coeffs5 = (V5.' * V5) \ (V5.' * yTrain);
coeffs8 = (V8.' * V8) \ (V8.' * yTrain);

% Evaluate polynomials on a grid of x values
xGrid = linspace(min(x), max(x), 100).';
VGrid3 = [xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];
VGrid5 = [xGrid.^5 xGrid.^4 xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];
VGrid8 = [xGrid.^8 xGrid.^7 xGrid.^6 xGrid.^5 xGrid.^4 xGrid.^3 xGrid.^2 xGrid ones(size(xGrid))];

yHat3 = VGrid3 * coeffs3;
yHat5 = VGrid5 * coeffs5;
yHat8 = VGrid8 * coeffs8;

% Plot data and polynomial approximations
figure;
plot(xTest, yTest, '.', xGrid, yHat3, xGrid, yHat5, xGrid, yHat8);
legend('Test data', 'Degree 3', 'Degree 5', 'Degree 8');
xlabel('x');
ylabel('y');

% Evaluate polynomials on test data
VTest3 = [xTest.^3 xTest.^2 xTest ones(size(xTest))];
VTest5 = [xTest.^5 xTest.^4 xTest.^3 xTest.^2 xTest ones(size(xTest))];
VTest8 = [xTest.^8 xTest.^7 xTest.^6 xTest.^5 xTest.^4 xTest.^3 xTest.^2 xTest ones(size(xTest))];

yTestHat3 = VTest3 * coeffs3;
yTestHat5 = VTest5 * coeffs5;
yTestHat8 = VTest8 * coeffs8;

% Compute errors for each degree on test data
testErr3 = yTest - yTestHat3;
testErr5 = yTest - yTestHat5;
testErr8 = yTest - yTestHat8;

% Plot errors on test data
figure;
hold on;
plot(xTest, testErr3, '.', 'DisplayName', 'Degree 3');
plot(xTest, testErr5, '.', 'DisplayName', 'Degree 5');
plot(xTest, testErr8, '.', 'DisplayName', 'Degree 8');
xlabel('x');
ylabel('Error');
legend('show');

% Compute and print R^2 and correlation coefficient for test data
SSres3 = sum(testErr3.^2);
SSres5 = sum(testErr5.^2);
SSres8 = sum(testErr8.^2);

yTestMean = mean(yTest);
SStot = sum((yTest - yTestMean).^2);

R2_3 = 1 - SSres3/SStot;
R2_5 = 1 - SSres5/SStot;
R2_8 = 1 - SSres8/SStot;

fprintf('The R^2 for degree 3 is %.6f', R2_3);
fprintf('\n');
fprintf('The R^2 for degree 5 is %.6f', R2_5);
fprintf('\n');
fprintf('The R^2 for degree 8 is %.6f', R2_8);
fprintf('\n');

r3 = corrcoef(xTest,yTestHat3);
r3 = r3(1,2);

r5 = corrcoef(xTest,yTestHat5);
r5 = r5(1,2);

r8 = corrcoef(xTest,yTestHat8);
r8 = r8(1,2);

fprintf('The correlation coefficient for degree 3 is %.6f', r3);
fprintf('\n');
fprintf('The correlation coefficient for degree 5 is %.6f', r5);
fprintf('\n');
fprintf('The correlation coefficient for degree 8 is %.6f', r8);
fprintf('\n');

%% QUESTION3

z0Train = ones(size(xTrain));
z1Train = cos(xTrain);
z2Train = sin(xTrain);
ZTrain = [z0Train, z1Train, z2Train]; % use comma to concatenate z0, z1, z2 horizontally
a = (ZTrain'*ZTrain)\ZTrain'*yTrain; % use backslash operator to solve (ZTrain'*ZTrain)a = ZTrain'yTrain for the vector of coeffs a.

a0 = a(1);
a1 = a(2);
a2 = a(3);

% Construct the approximation for train data
yhatTrain = a0*z0Train + a1*z1Train + a2*z2Train;


% Plot the training data and the approximation
figure;
plot(xTrain, yTrain, '.', 'DisplayName', 'Training Data');
hold on;
plot(xTrain, yhatTrain, '.', 'DisplayName', 'Approximation');
grid on;
legend;
xlabel('x');
ylabel('y');
title('Training Data and Approximation');

% Plot the relative error for train data
figure;
abserrorTrain = abs(yTrain - yhatTrain);
relativeTrain = abserrorTrain./abs(yTrain);
plot(xTrain, relativeTrain, '.', 'DisplayName', 'Relative Error');
grid on;
xlabel('x');
ylabel('Relative Error');
title('Relative Error for Training Data');

% Construct the approximation for test data
z0Test = ones(size(xTest));
z1Test = cos(xTest);
z2Test = sin(xTest);
ZTest = [z0Test, z1Test, z2Test]; % use comma to concatenate z0, z1, z2 horizontally
yhatTest = a0*z0Test + a1*z1Test + a2*z2Test;


% Plot the test data and the approximation
figure;
plot(xTest, yTest, '.', 'DisplayName', 'Test Data');
hold on;
plot(xTest, yhatTest, '.', 'DisplayName', 'Approximation');
grid on;
legend;
xlabel('x');
ylabel('y');
title('Test Data and Approximation');

% Plot the relative error for test data
figure;
abserrorTest = abs(yTest - yhatTest);
relativeTest = abserrorTest./abs(yTest);
plot(xTest, relativeTest, '.', 'DisplayName', 'Relative Error');
grid on;
xlabel('x');
ylabel('Relative Error');
title('Relative Error for Test Data');